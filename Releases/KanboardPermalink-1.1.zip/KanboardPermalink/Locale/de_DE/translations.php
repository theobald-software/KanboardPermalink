<?php
return array(
  'Copy Permalink' => 'Permalink Kopieren',
  'Adds a convenient link to copy the task url to the clipboard' => 'Fügt einen praktischen Link hinzu, um die Aufgaben-URL in die Zwischenablage zu kopieren',
);
