# Changelog


## v1.1

### What's Changed

_(most recent changes are listed on top):_
- Bug fixes and general improvements


## v1.0

### What's Changed

_(most recent changes are listed on top):_
- Plugin published to Kanboard Plugins Directory
- Link in dropdown and sidebar now shown at the top
- Added tooltip to the link
- Added alt code icons to response alerts
- Added `en_GB`, `fr_FR`, `de_DE` translations
- Plugin can now be translated
- Kanboard minimum version updated to `v1.2.20`
- Delete previous versions of this plugin to avoid conflicts (due to namespace change)


## v0.1.0

### What's Changed

_(most recent changes are listed on top):_
- Initial release



Read the full [**Changelog**](../master/changelog.md "See changes") or view the [**README**](../master/README.md "View README")
