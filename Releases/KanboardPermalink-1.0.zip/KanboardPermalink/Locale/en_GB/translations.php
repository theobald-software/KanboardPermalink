<?php
return array(
  'Copy Permalink' => 'Copy Permalink',
  'Adds a convenient link to copy the task url to the clipboard' => 'Adds a convenient link to copy the task url to the clipboard',
);
