<?php
return array(
  'Copy Permalink' => 'Copier le lien Permanent',
  'Adds a convenient link to copy the task url to the clipboard' => 'Ajoute un lien pratique pour copier l&#39;URL de la tâche dans le presse-papiers',
);
